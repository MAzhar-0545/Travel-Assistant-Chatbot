#!/usr/bin/env python3
"""
Gradio Web Interface for Kavak Travel Assistant
An alternative web UI using Gradio for the travel chatbot.
"""

import gradio as gr
import os
import json
from datetime import datetime
from typing import List, Tuple
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Import the main travel assistant
from main import TravelAssistant

# Global assistant instance
assistant = None

def initialize_assistant(api_key: str) -> str:
    """Initialize the travel assistant with API key."""
    global assistant
    
    if not api_key:
        return "❌ Please provide an OpenAI API key."
    
    try:
        assistant = TravelAssistant(api_key)
        return "✅ Travel Assistant initialized successfully!"
    except Exception as e:
        return f"❌ Failed to initialize assistant: {str(e)}"

def chat_with_assistant(message: str, history: List[Tuple[str, str]]) -> Tuple[str, List[Tuple[str, str]]]:
    """Chat with the travel assistant."""
    global assistant
    
    if not assistant:
        response = "⚠️ Please initialize the assistant first by providing your OpenAI API key in the settings."
    else:
        try:
            response = assistant.chat_sync(message)
        except Exception as e:
            response = f"❌ Error: {str(e)}. Please try rephrasing your question."
    
    # Update history
    history.append((message, response))
    return "", history

def clear_chat() -> List[Tuple[str, str]]:
    """Clear chat history."""
    return []

def get_sample_queries() -> List[str]:
    """Get sample queries for quick testing."""
    return [
        "Find me a round-trip to Tokyo in August with Star Alliance airlines only. I want to avoid overnight layovers.",
        "Do I need a visa to visit Japan with a UAE passport?",
        "What's the refund policy for refundable tickets?",
        "Show me business class flights from Dubai to London under $1500",
        "Can I get a refund if I cancel due to medical emergency?",
        "What are the entry requirements for US citizens traveling to Japan?"
    ]

def use_sample_query(query: str) -> str:
    """Use a sample query."""
    return query

def get_flight_statistics() -> str:
    """Get flight database statistics."""
    global assistant
    
    if not assistant:
        return "Assistant not initialized."
    
    try:
        stats = assistant.flight_engine.get_flight_statistics()
        if not stats:
            return "No flight data available."
        
        return f"""
📊 **Flight Database Statistics**

• Total Flights: {stats.get('total_flights', 0)}
• Airlines: {len(stats.get('airlines', []))}
• Destinations: {len(stats.get('destinations', []))}
• Origins: {len(stats.get('origins', []))}
• Price Range: ${stats.get('price_range', {}).get('min', 0):.0f} - ${stats.get('price_range', {}).get('max', 0):.0f}
• Average Price: ${stats.get('price_range', {}).get('avg', 0):.0f}
        """
    except Exception as e:
        return f"Error getting statistics: {str(e)}"

def create_interface():
    """Create the Gradio interface."""
    
    # Custom CSS for better styling
    css = """
    .gradio-container {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    
    .header {
        text-align: center;
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 2rem;
        border-radius: 10px;
        margin-bottom: 1rem;
    }
    
    .sample-queries {
        background: #f8f9fa;
        padding: 1rem;
        border-radius: 8px;
        margin: 1rem 0;
    }
    
    .stats-box {
        background: #e8f4fd;
        padding: 1rem;
        border-radius: 8px;
        border-left: 4px solid #1f77b4;
    }
    """
    
    with gr.Blocks(css=css, title="Kavak Travel Assistant") as interface:
        
        # Header
        gr.HTML("""
        <div class="header">
            <h1>✈️ Kavak Travel Assistant</h1>
            <p>Your intelligent companion for international travel planning</p>
        </div>
        """)
        
        with gr.Row():
            with gr.Column(scale=2):
                # Main chat interface
                chatbot = gr.Chatbot(
                    label="💬 Chat with Travel Assistant",
                    height=500,
                    show_label=True,
                    container=True
                )
                
                with gr.Row():
                    msg = gr.Textbox(
                        label="Your Message",
                        placeholder="Ask me about flights, visas, or travel policies...",
                        scale=4
                    )
                    send_btn = gr.Button("Send 📤", scale=1, variant="primary")
                
                with gr.Row():
                    clear_btn = gr.Button("Clear Chat 🗑️", variant="secondary")
                
            with gr.Column(scale=1):
                # Settings and controls
                gr.Markdown("### ⚙️ Settings")
                
                api_key_input = gr.Textbox(
                    label="OpenAI API Key",
                    type="password",
                    value=os.getenv('OPENAI_API_KEY', ''),
                    placeholder="Enter your OpenAI API key"
                )
                
                init_btn = gr.Button("Initialize Assistant 🚀", variant="primary")
                init_status = gr.Textbox(label="Status", interactive=False)
                
                gr.Markdown("### 💡 Sample Queries")
                
                sample_dropdown = gr.Dropdown(
                    choices=get_sample_queries(),
                    label="Quick Examples",
                    value=None
                )
                
                use_sample_btn = gr.Button("Use Sample Query 📝")
                
                gr.Markdown("### 📊 Statistics")
                
                stats_btn = gr.Button("Show Flight Stats 📈")
                stats_display = gr.Markdown("Click button to view statistics")
        
        # Information section
        with gr.Row():
            gr.Markdown("""
            ### 🌟 Features
            
            - **🔍 Flight Search**: Find flights using natural language queries
            - **📋 Visa Information**: Get visa requirements and travel policies  
            - **🤖 AI-Powered**: Intelligent responses using LangChain and OpenAI
            - **🌍 Multi-Alliance**: Search across Star Alliance, SkyTeam, and oneworld
            - **💬 Conversational**: Natural, context-aware interactions
            
            ### 📝 Example Queries
            
            - "Find me a round-trip to Tokyo in August with Star Alliance airlines"
            - "Do I need a visa for Japan with a UAE passport?"
            - "What's the refund policy for cancellations?"
            - "Show me business class flights under $1500"
            """)
        
        # Event handlers
        def handle_send(message, history):
            return chat_with_assistant(message, history)
        
        # Connect events
        send_btn.click(
            handle_send,
            inputs=[msg, chatbot],
            outputs=[msg, chatbot]
        )
        
        msg.submit(
            handle_send,
            inputs=[msg, chatbot],
            outputs=[msg, chatbot]
        )
        
        clear_btn.click(
            clear_chat,
            outputs=[chatbot]
        )
        
        init_btn.click(
            initialize_assistant,
            inputs=[api_key_input],
            outputs=[init_status]
        )
        
        use_sample_btn.click(
            use_sample_query,
            inputs=[sample_dropdown],
            outputs=[msg]
        )
        
        stats_btn.click(
            get_flight_statistics,
            outputs=[stats_display]
        )
        
        # Footer
        gr.HTML("""
        <div style="text-align: center; color: #666; padding: 2rem; margin-top: 2rem; border-top: 1px solid #eee;">
            <p>🌟 <strong>Kavak Travel Assistant</strong> - Powered by LangChain & OpenAI</p>
            <p><small>⚠️ Always verify travel information with official sources before making decisions.</small></p>
            <p><small>Built for Kavak Technical Assessment</small></p>
        </div>
        """)
    
    return interface

def main():
    """Main function to launch the Gradio app."""
    interface = create_interface()
    
    # Launch the interface
    interface.launch(
        server_name="0.0.0.0",
        server_port=7860,
        share=False,
        show_error=True,
        show_tips=True,
        enable_queue=True
    )

if __name__ == "__main__":
    main()