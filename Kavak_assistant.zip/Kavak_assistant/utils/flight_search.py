"""Flight search engine for the Kavak Travel Assistant."""

import json
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import re


class FlightSearchEngine:
    """Handles flight search and filtering operations."""
    
    def __init__(self):
        self.flights = []
        self.airline_alliances = {
            'Star Alliance': [
                'Turkish Airlines', 'Lufthansa', 'United Airlines', 'Singapore Airlines',
                'ANA', 'Air Canada', 'Swiss', 'Austrian Airlines', 'SAS', 'Thai Airways'
            ],
            'SkyTeam': [
                'Emirates', 'Delta Air Lines', 'Air France', 'KLM', 'Korean Air',
                'China Eastern', 'Aeroflot', 'Alitalia', 'Vietnam Airlines'
            ],
            'oneworld': [
                'American Airlines', 'British Airways', 'Cathay Pacific', 'Qantas',
                'Japan Airlines', 'Iberia', 'Finnair', 'Qatar Airways', 'Royal Jordanian'
            ]
        }
    
    def load_flights(self, flights_data: List[Dict[str, Any]]):
        """Load flight data into the search engine."""
        self.flights = flights_data
        # Ensure all flights have required fields
        for flight in self.flights:
            if 'alliance' not in flight:
                flight['alliance'] = self._get_airline_alliance(flight.get('airline', ''))
    
    def _get_airline_alliance(self, airline: str) -> str:
        """Get the alliance for a given airline."""
        for alliance, airlines in self.airline_alliances.items():
            if airline in airlines:
                return alliance
        return 'Independent'
    
    def _normalize_city_name(self, city: str) -> str:
        """Normalize city names for better matching."""
        if not city:
            return ''
        # Remove common airport codes and normalize
        city = re.sub(r'\([A-Z]{3}\)', '', city).strip()
        return city.lower().strip()
    
    def _parse_date(self, date_str: str) -> Optional[datetime]:
        """Parse date string to datetime object."""
        if not date_str:
            return None
        
        try:
            # Try different date formats
            for fmt in ['%Y-%m-%d', '%m/%d/%Y', '%d/%m/%Y', '%Y-%m-%d %H:%M:%S']:
                try:
                    return datetime.strptime(date_str, fmt)
                except ValueError:
                    continue
            return None
        except Exception:
            return None
    
    def _matches_criteria(self, flight: Dict[str, Any], criteria: Dict[str, Any]) -> bool:
        """Check if a flight matches the search criteria."""
        
        # Origin/destination matching
        if criteria.get('origin'):
            flight_from = self._normalize_city_name(flight.get('from', ''))
            search_from = self._normalize_city_name(criteria['origin'])
            if search_from not in flight_from and flight_from not in search_from:
                return False
        
        if criteria.get('destination'):
            flight_to = self._normalize_city_name(flight.get('to', ''))
            search_to = self._normalize_city_name(criteria['destination'])
            if search_to not in flight_to and flight_to not in search_to:
                return False
        
        # Date matching
        if criteria.get('departure_date'):
            flight_date = self._parse_date(flight.get('departure_date', ''))
            search_date = self._parse_date(criteria['departure_date'])
            if flight_date and search_date:
                # Allow some flexibility (±3 days)
                date_diff = abs((flight_date - search_date).days)
                if date_diff > 3:
                    return False
        
        # Trip type filtering
        search_trip_type = criteria.get('trip_type', '')
        flight_has_return = bool(flight.get('return_date'))
        
        if search_trip_type == 'one-way' and flight_has_return:
            return False  # Skip round-trip flights when searching for one-way
        elif search_trip_type == 'round-trip' and not flight_has_return:
            return False  # Skip one-way flights when searching for round-trip
        
        # Return date for round trips
        if criteria.get('return_date') and criteria.get('trip_type') == 'round-trip':
            flight_return = self._parse_date(flight.get('return_date', ''))
            search_return = self._parse_date(criteria['return_date'])
            if flight_return and search_return:
                date_diff = abs((flight_return - search_return).days)
                if date_diff > 3:
                    return False
        
        # Airline preferences
        if criteria.get('preferred_airlines'):
            flight_airline = flight.get('airline', '').lower()
            preferred = [airline.lower() for airline in criteria['preferred_airlines']]
            if not any(pref in flight_airline for pref in preferred):
                return False
        
        # Alliance preferences
        if criteria.get('preferred_alliance'):
            flight_alliance = flight.get('alliance', '')
            if criteria['preferred_alliance'].lower() not in flight_alliance.lower():
                return False
        
        # Layover preferences
        if criteria.get('max_layovers') is not None:
            flight_layovers = len(flight.get('layovers', []))
            if flight_layovers > criteria['max_layovers']:
                return False
        
        # Avoid overnight layovers
        if criteria.get('avoid_overnight_layovers'):
            # This is a simplified check - in real implementation,
            # you'd check actual layover durations
            layovers = flight.get('layovers', [])
            if len(layovers) > 1:  # Multiple layovers might indicate overnight
                return False
        
        # Price constraints
        if criteria.get('max_price'):
            flight_price = flight.get('price_usd', float('inf'))
            if flight_price > criteria['max_price']:
                return False
        
        # Refundable preference
        if criteria.get('refundable_only'):
            if not flight.get('refundable', False):
                return False
        
        # Travel class (if specified in flight data)
        if criteria.get('class') and 'class' in flight:
            if flight['class'].lower() != criteria['class'].lower():
                return False
        
        return True
    
    def search_flights(self, criteria: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Search flights based on criteria."""
        if not self.flights:
            return []
        
        # Filter flights based on criteria
        matching_flights = [
            flight for flight in self.flights 
            if self._matches_criteria(flight, criteria)
        ]
        
        # Sort by price (ascending) and then by number of layovers
        matching_flights.sort(key=lambda x: (
            x.get('price_usd', float('inf')),
            len(x.get('layovers', []))
        ))
        
        return matching_flights
    
    def get_flight_statistics(self) -> Dict[str, Any]:
        """Get statistics about available flights."""
        if not self.flights:
            return {}
        
        airlines = set(flight.get('airline') for flight in self.flights)
        destinations = set(flight.get('to') for flight in self.flights)
        origins = set(flight.get('from') for flight in self.flights)
        refundable_count = sum(1 for flight in self.flights if flight.get('refundable', False))
        
        price_range = {
            'min': min(flight.get('price_usd', 0) for flight in self.flights),
            'max': max(flight.get('price_usd', 0) for flight in self.flights),
            'avg': sum(flight.get('price_usd', 0) for flight in self.flights) / len(self.flights)
        }
        
        return {
            'total_flights': len(self.flights),
            'airlines': list(airlines),
            'destinations': list(destinations),
            'origins': list(origins),
            'refundable_count': refundable_count,
            'price_range': price_range
        }
    
    def suggest_alternatives(self, criteria: Dict[str, Any]) -> List[str]:
        """Suggest alternative search criteria if no flights found."""
        suggestions = []
        
        # Check if relaxing date constraints helps
        if criteria.get('departure_date'):
            suggestions.append("Try flexible dates (±1 week)")
        
        # Check if removing airline preference helps
        if criteria.get('preferred_airlines'):
            suggestions.append("Consider other airlines")
        
        # Check if allowing more layovers helps
        if criteria.get('max_layovers') is not None and criteria['max_layovers'] < 2:
            suggestions.append("Allow more layovers for better prices")
        
        # Check if increasing budget helps
        if criteria.get('max_price'):
            suggestions.append("Consider increasing your budget")
        
        # Check nearby airports
        if criteria.get('origin') or criteria.get('destination'):
            suggestions.append("Try nearby airports or cities")
        
        return suggestions