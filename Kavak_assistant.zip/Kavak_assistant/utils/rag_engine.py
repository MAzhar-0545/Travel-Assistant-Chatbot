"""RAG (Retrieval-Augmented Generation) engine for travel policies and visa information."""

import os
from typing import List, Dict, Any, Optional

from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.schema import Document
from langchain_community.vectorstores import FAISS
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain.chains import RetrievalQA
from langchain.prompts import PromptTemplate

from prompts.system_prompts import RAG_PROMPT


class RAGEngine:
    """Handles retrieval-augmented generation for travel information."""
    
    def __init__(self, openai_api_key: str):
        self.openai_api_key = openai_api_key
        self.embeddings = OpenAIEmbeddings(api_key=openai_api_key)
        self.llm = ChatOpenAI(
            api_key=openai_api_key,
            model="gpt-3.5-turbo",
            temperature=0.3  # Lower temperature for factual responses
        )
        self.vectorstore = None
        self.qa_chain = None
        
        # Text splitter for chunking documents
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200,
            length_function=len,
            separators=["\n\n", "\n", ".", "!", "?", ",", " ", ""]
        )
    
    def setup_knowledge_base(self, content: str, metadata: Optional[Dict[str, Any]] = None):
        """Setup the knowledge base from text content."""
        try:
            # Split the content into chunks
            chunks = self.text_splitter.split_text(content)
            
            # Create documents with metadata
            documents = []
            for i, chunk in enumerate(chunks):
                doc_metadata = metadata or {}
                doc_metadata.update({
                    'chunk_id': i,
                    'source': 'visa_rules',
                    'chunk_size': len(chunk)
                })
                documents.append(Document(page_content=chunk, metadata=doc_metadata))
            
            # Create vector store
            self.vectorstore = FAISS.from_documents(documents, self.embeddings)
            
            # Setup QA chain
            self._setup_qa_chain()
            
            print(f"Knowledge base created with {len(documents)} document chunks")
            
        except Exception as e:
            print(f"Error setting up knowledge base: {e}")
            raise
    
    def _setup_qa_chain(self):
        """Setup the QA chain for retrieval."""
        if not self.vectorstore:
            raise ValueError("Vector store not initialized")
        
        # Create retriever
        retriever = self.vectorstore.as_retriever(
            search_type="similarity",
            search_kwargs={"k": 3}  # Retrieve top 3 most relevant chunks
        )
        
        # Create custom prompt template
        prompt_template = PromptTemplate(
            template=RAG_PROMPT,
            input_variables=["context", "question"]
        )
        
        # Create QA chain
        self.qa_chain = RetrievalQA.from_chain_type(
            llm=self.llm,
            chain_type="stuff",
            retriever=retriever,
            chain_type_kwargs={"prompt": prompt_template},
            return_source_documents=True
        )
    
    def query(self, question: str) -> str:
        """Query the knowledge base for information."""
        if not self.qa_chain:
            return "Knowledge base not initialized. Please check if visa_rules.md file exists."
        
        try:
            # Get response from QA chain
            result = self.qa_chain.invoke({"query": question})
            
            answer = result["result"]
            source_docs = result.get("source_documents", [])
            
            # Add source information if available
            if source_docs:
                answer += "\n\n📚 **Sources:**\n"
                for i, doc in enumerate(source_docs[:2], 1):  # Show top 2 sources
                    chunk_info = doc.metadata.get('chunk_id', 'Unknown')
                    answer += f"- Document chunk {chunk_info}\n"
            
            # Add disclaimer
            answer += "\n⚠️ **Important:** Please verify this information with official government sources before traveling."
            
            return answer
            
        except Exception as e:
            return f"Error retrieving information: {str(e)}. Please try rephrasing your question."
    
    def add_document(self, content: str, metadata: Optional[Dict[str, Any]] = None):
        """Add a new document to the knowledge base."""
        if not self.vectorstore:
            self.setup_knowledge_base(content, metadata)
            return
        
        try:
            # Split content into chunks
            chunks = self.text_splitter.split_text(content)
            
            # Create documents
            documents = []
            for i, chunk in enumerate(chunks):
                doc_metadata = metadata or {}
                doc_metadata.update({
                    'chunk_id': f"new_{i}",
                    'source': metadata.get('source', 'additional_doc') if metadata else 'additional_doc'
                })
                documents.append(Document(page_content=chunk, metadata=doc_metadata))
            
            # Add to existing vector store
            self.vectorstore.add_documents(documents)
            
            print(f"Added {len(documents)} new document chunks to knowledge base")
            
        except Exception as e:
            print(f"Error adding document: {e}")
    
    def search_similar(self, query: str, k: int = 5) -> List[Dict[str, Any]]:
        """Search for similar documents without generating an answer."""
        if not self.vectorstore:
            return []
        
        try:
            # Perform similarity search
            docs = self.vectorstore.similarity_search_with_score(query, k=k)
            
            results = []
            for doc, score in docs:
                results.append({
                    'content': doc.page_content,
                    'metadata': doc.metadata,
                    'similarity_score': score
                })
            
            return results
            
        except Exception as e:
            print(f"Error in similarity search: {e}")
            return []
    
    def get_knowledge_base_stats(self) -> Dict[str, Any]:
        """Get statistics about the knowledge base."""
        if not self.vectorstore:
            return {'status': 'not_initialized'}
        
        try:
            # Get vector store statistics
            index_size = self.vectorstore.index.ntotal if hasattr(self.vectorstore, 'index') else 'unknown'
            
            return {
                'status': 'initialized',
                'index_size': index_size,
                'embedding_dimension': len(self.embeddings.embed_query("test")) if self.embeddings else 'unknown'
            }
            
        except Exception as e:
            return {
                'status': 'error',
                'error': str(e)
            }
    
    def update_knowledge_base(self, new_content: str):
        """Update the entire knowledge base with new content."""
        try:
            # Recreate the knowledge base
            self.setup_knowledge_base(new_content)
            print("Knowledge base updated successfully")
            
        except Exception as e:
            print(f"Error updating knowledge base: {e}")
            raise