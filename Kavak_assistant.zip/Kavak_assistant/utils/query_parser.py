"""Query parser for natural language travel queries."""

import json
import re
from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta
from dateutil import parser as date_parser
from dateutil.relativedelta import relativedelta

from langchain_openai import ChatOpenAI
from langchain.prompts import PromptTemplate
from langchain.schema import HumanMessage, SystemMessage

from prompts.system_prompts import QUERY_PARSING_PROMPT


class QueryParser:
    """Handles parsing of natural language travel queries."""
    
    def __init__(self, llm: ChatOpenAI):
        self.llm = llm
        
        # Common airline alliances
        self.alliances = {
            'star alliance': 'Star Alliance',
            'star': 'Star Alliance',
            'skyteam': 'SkyTeam',
            'sky team': 'SkyTeam',
            'oneworld': 'oneworld',
            'one world': 'oneworld'
        }
        
        # Common airlines
        self.airlines = {
            'turkish': 'Turkish Airlines',
            'emirates': 'Emirates',
            'lufthansa': 'Lufthansa',
            'united': 'United Airlines',
            'american': 'American Airlines',
            'british airways': 'British Airways',
            'air france': 'Air France',
            'klm': 'KLM',
            'singapore': 'Singapore Airlines',
            'qatar': 'Qatar Airways',
            'etihad': 'Etihad Airways',
            'cathay': 'Cathay Pacific',
            'ana': 'ANA',
            'jal': 'Japan Airlines'
        }
        
        # Travel class mappings
        self.travel_classes = {
            'economy': 'economy',
            'eco': 'economy',
            'coach': 'economy',
            'business': 'business',
            'biz': 'business',
            'first': 'first',
            'first class': 'first'
        }
        
        # Month mappings
        self.months = {
            'january': 1, 'jan': 1,
            'february': 2, 'feb': 2,
            'march': 3, 'mar': 3,
            'april': 4, 'apr': 4,
            'may': 5,
            'june': 6, 'jun': 6,
            'july': 7, 'jul': 7,
            'august': 8, 'aug': 8,
            'september': 9, 'sep': 9, 'sept': 9,
            'october': 10, 'oct': 10,
            'november': 11, 'nov': 11,
            'december': 12, 'dec': 12
        }
    
    def parse_flight_query(self, query: str) -> Dict[str, Any]:
        """Parse a natural language flight query into structured data."""
        try:
            # First, try rule-based parsing for common patterns
            rule_based_result = self._rule_based_parsing(query)
            
            # Then use LLM for more complex parsing
            llm_result = self._llm_based_parsing(query)
            
            # Merge results, preferring LLM results where available
            final_result = {**rule_based_result, **{k: v for k, v in llm_result.items() if v is not None}}
            
            # Post-process and validate
            final_result = self._post_process_result(final_result)
            
            return final_result
            
        except Exception as e:
            print(f"Error parsing query: {e}")
            return self._get_default_result()
    
    def _rule_based_parsing(self, query: str) -> Dict[str, Any]:
        """Enhanced rule-based parsing for comprehensive travel parameters."""
        query_lower = query.lower()
        result = self._get_default_result()
        
        # Extract cities/airports with enhanced patterns
        city_patterns = [
            r'from\s+([a-zA-Z\s]+?)\s+to\s+([a-zA-Z\s]+)',
            r'([a-zA-Z\s]+?)\s+to\s+([a-zA-Z\s]+)',
            r'flying\s+from\s+([a-zA-Z\s]+?)\s+to\s+([a-zA-Z\s]+)',
            r'origin[:\s]+([a-zA-Z\s]+?)\s+destination[:\s]+([a-zA-Z\s]+)',
            r'departure[:\s]+([a-zA-Z\s]+?)\s+arrival[:\s]+([a-zA-Z\s]+)'
        ]
        
        for pattern in city_patterns:
            match = re.search(pattern, query_lower)
            if match:
                result['origin'] = match.group(1).strip().title()
                result['destination'] = match.group(2).strip().title()
                break
        
        # Extract trip type
        if any(word in query_lower for word in ['round trip', 'round-trip', 'return']):
            result['trip_type'] = 'round-trip'
        elif any(word in query_lower for word in ['one way', 'one-way', 'single']):
            result['trip_type'] = 'one-way'
        
        # Extract airlines with enhanced detection
        for airline_key, airline_name in self.airlines.items():
            if airline_key in query_lower:
                if result['preferred_airlines'] is None:
                    result['preferred_airlines'] = []
                result['preferred_airlines'].append(airline_name)
        
        # Extract alliances
        for alliance_key, alliance_name in self.alliances.items():
            if alliance_key in query_lower:
                result['preferred_alliance'] = alliance_name
        
        # Extract layover preferences
        if any(word in query_lower for word in ['direct', 'non-stop', 'nonstop', 'no layover']):
            result['max_layovers'] = 0
        elif any(word in query_lower for word in ['one stop', '1 stop', 'single layover']):
            result['max_layovers'] = 1
        elif any(word in query_lower for word in ['two stops', '2 stops', 'multiple layovers']):
            result['max_layovers'] = 2
        
        # Extract cost preferences
        cost_patterns = [
            r'under\s+\$?([0-9,]+)',
            r'less than\s+\$?([0-9,]+)',
            r'budget\s+\$?([0-9,]+)',
            r'max\s+\$?([0-9,]+)',
            r'maximum\s+\$?([0-9,]+)'
        ]
        
        for pattern in cost_patterns:
            match = re.search(pattern, query_lower)
            if match:
                result['max_price'] = int(match.group(1).replace(',', ''))
                break
        
        # Extract class preferences
        if any(word in query_lower for word in ['business', 'business class']):
            result['class'] = 'business'
        elif any(word in query_lower for word in ['first', 'first class']):
            result['class'] = 'first'
        elif any(word in query_lower for word in ['premium', 'premium economy']):
            result['class'] = 'premium_economy'
        elif any(word in query_lower for word in ['economy', 'coach']):
            result['class'] = 'economy'
        
        # Extract alliances
        for alliance_key, alliance_name in self.alliances.items():
            if alliance_key in query_lower:
                result['preferred_alliance'] = alliance_name
                break
        
        # Extract travel class
        for class_key, class_name in self.travel_classes.items():
            if class_key in query_lower:
                result['class'] = class_name
                break
        
        # Extract layover preferences
        if any(phrase in query_lower for phrase in ['direct', 'non-stop', 'nonstop', 'no layover']):
            result['max_layovers'] = 0
        elif any(phrase in query_lower for phrase in ['avoid overnight', 'no overnight']):
            result['avoid_overnight_layovers'] = True
        
        # Extract refundable preference
        if any(phrase in query_lower for phrase in ['refundable', 'flexible', 'changeable']):
            result['refundable_only'] = True
        
        # Extract price constraints
        price_match = re.search(r'under\s+\$?(\d+)|less\s+than\s+\$?(\d+)|budget\s+\$?(\d+)', query_lower)
        if price_match:
            price = int(price_match.group(1) or price_match.group(2) or price_match.group(3))
            result['max_price'] = price
        
        # Extract dates
        result.update(self._extract_dates(query))
        
        return result
    
    def _llm_based_parsing(self, query: str) -> Dict[str, Any]:
        """Use LLM for complex query parsing."""
        try:
            prompt = QUERY_PARSING_PROMPT.format(query=query)
            
            messages = [
                SystemMessage(content="You are an expert travel query parser. Return only valid JSON."),
                HumanMessage(content=prompt)
            ]
            
            response = self.llm.invoke(messages)
            
            # Extract JSON from response
            response_text = response.content.strip()
            
            # Try to find JSON in the response
            json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
            if json_match:
                json_str = json_match.group(0)
                parsed_result = json.loads(json_str)
                return parsed_result
            else:
                # Try to parse the entire response as JSON
                return json.loads(response_text)
                
        except Exception as e:
            print(f"LLM parsing error: {e}")
            return {}
    
    def _extract_dates(self, query: str) -> Dict[str, Any]:
        """Extract dates from query text."""
        result = {}
        query_lower = query.lower()
        
        # Look for month names
        current_date = datetime.now()
        
        # Extract specific months with descriptive phrases
        for month_name, month_num in self.months.items():
            if month_name in query_lower:
                # Determine year (current year or next year if month has passed)
                year = current_date.year
                if month_num < current_date.month:
                    year += 1
                
                # Handle descriptive date phrases
                departure_day = 15  # default
                return_day = 15     # default
                
                # Check for specific timing within the month
                if 'start' in query_lower or 'beginning' in query_lower or 'early' in query_lower:
                    departure_day = 1
                elif 'mid' in query_lower or 'middle' in query_lower:
                    departure_day = 15
                elif 'end' in query_lower or 'late' in query_lower:
                    departure_day = 28
                
                # Handle return timing
                if 'mid' in query_lower and ('return' in query_lower or 'back' in query_lower):
                    return_day = 15
                elif 'end' in query_lower and ('return' in query_lower or 'back' in query_lower):
                    return_day = 28
                
                departure_date = datetime(year, month_num, departure_day)
                result['departure_date'] = departure_date.strftime('%Y-%m-%d')
                
                # For round trips, check for return timing or default to 2 weeks later
                if 'round' in query_lower or 'return' in query_lower or 'back' in query_lower:
                    if 'mid' in query_lower and ('return' in query_lower or 'back' in query_lower):
                        return_date = datetime(year, month_num, return_day)
                    else:
                        return_date = departure_date + timedelta(days=14)
                    result['return_date'] = return_date.strftime('%Y-%m-%d')
                break
        
        # Look for relative dates
        if 'next month' in query_lower:
            next_month = current_date + relativedelta(months=1)
            result['departure_date'] = next_month.replace(day=15).strftime('%Y-%m-%d')
        
        elif 'next week' in query_lower:
            next_week = current_date + timedelta(weeks=1)
            result['departure_date'] = next_week.strftime('%Y-%m-%d')
        
        # Look for specific date patterns
        date_patterns = [
            r'(\d{1,2})/(\d{1,2})/(\d{4})',  # MM/DD/YYYY
            r'(\d{4})-(\d{1,2})-(\d{1,2})',  # YYYY-MM-DD
            r'(\d{1,2})\s+(\w+)\s+(\d{4})'   # DD Month YYYY
        ]
        
        for pattern in date_patterns:
            matches = re.findall(pattern, query)
            if matches:
                try:
                    # Try to parse the first match as departure date
                    date_str = '/'.join(matches[0]) if '/' in pattern else '-'.join(matches[0])
                    parsed_date = date_parser.parse(date_str)
                    result['departure_date'] = parsed_date.strftime('%Y-%m-%d')
                    
                    # If there's a second match, use it as return date
                    if len(matches) > 1:
                        return_date_str = '/'.join(matches[1]) if '/' in pattern else '-'.join(matches[1])
                        parsed_return = date_parser.parse(return_date_str)
                        result['return_date'] = parsed_return.strftime('%Y-%m-%d')
                    
                    break
                except Exception:
                    continue
        
        return result
    
    def _post_process_result(self, result: Dict[str, Any]) -> Dict[str, Any]:
        """Post-process and validate the parsing result."""
        # Ensure dates are in correct format
        for date_field in ['departure_date', 'return_date']:
            if result.get(date_field):
                try:
                    # Validate and reformat date
                    parsed_date = date_parser.parse(result[date_field])
                    result[date_field] = parsed_date.strftime('%Y-%m-%d')
                except Exception:
                    result[date_field] = None
        
        # Validate trip type consistency
        if result.get('return_date') and result.get('trip_type') == 'one-way':
            result['trip_type'] = 'round-trip'
        elif not result.get('return_date') and result.get('trip_type') == 'round-trip':
            result['trip_type'] = 'one-way'
        
        # Clean up airline names
        if result.get('preferred_airlines'):
            result['preferred_airlines'] = list(set(result['preferred_airlines']))  # Remove duplicates
        
        # Validate numeric fields
        for field in ['max_layovers', 'max_price', 'passengers']:
            if result.get(field) is not None:
                try:
                    result[field] = int(result[field])
                except (ValueError, TypeError):
                    result[field] = None
        
        # Validate boolean fields
        for field in ['avoid_overnight_layovers', 'refundable_only', 'flexible_dates']:
            if result.get(field) is not None:
                result[field] = bool(result[field])
        
        return result
    
    def _get_default_result(self) -> Dict[str, Any]:
        """Get default result structure."""
        return {
            'origin': None,
            'destination': None,
            'departure_date': None,
            'return_date': None,
            'trip_type': None,
            'preferred_airlines': None,
            'preferred_alliance': None,
            'max_layovers': None,
            'avoid_overnight_layovers': None,
            'max_price': None,
            'refundable_only': None,
            'class': None,
            'passengers': 1,
            'flexible_dates': None
        }
    
    def extract_intent(self, query: str) -> str:
        """Extract the main intent from the query."""
        query_lower = query.lower()
        
        # Flight search intents
        if any(word in query_lower for word in ['find', 'search', 'book', 'flight', 'fly', 'travel']):
            return 'flight_search'
        
        # Visa/policy information intents
        elif any(word in query_lower for word in ['visa', 'passport', 'entry', 'requirement', 'policy']):
            return 'visa_info'
        
        # Refund/cancellation intents
        elif any(word in query_lower for word in ['refund', 'cancel', 'change', 'modify']):
            return 'policy_info'
        
        # General travel advice
        elif any(word in query_lower for word in ['advice', 'recommend', 'suggest', 'help']):
            return 'travel_advice'
        
        else:
            return 'general'
    
    def validate_query(self, parsed_query: Dict[str, Any]) -> List[str]:
        """Validate parsed query and return list of issues."""
        issues = []
        
        # Check for required fields
        if not parsed_query.get('origin'):
            issues.append("Origin city/airport not specified")
        
        if not parsed_query.get('destination'):
            issues.append("Destination city/airport not specified")
        
        # Check date logic
        if parsed_query.get('departure_date') and parsed_query.get('return_date'):
            try:
                dep_date = date_parser.parse(parsed_query['departure_date'])
                ret_date = date_parser.parse(parsed_query['return_date'])
                
                if ret_date <= dep_date:
                    issues.append("Return date must be after departure date")
                    
                if (ret_date - dep_date).days > 365:
                    issues.append("Trip duration seems unusually long (>1 year)")
                    
            except Exception:
                issues.append("Invalid date format")
        
        # Check price constraints
        if parsed_query.get('max_price') and parsed_query['max_price'] < 50:
            issues.append("Price constraint seems too low for international flights")
        
        return issues