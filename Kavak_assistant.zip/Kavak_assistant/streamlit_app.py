#!/usr/bin/env python3
"""
Streamlit Web Interface for Kavak Travel Assistant
A beautiful and modern web UI for the travel chatbot.
"""

import streamlit as st
import os
import json
from datetime import datetime
import asyncio
from typing import Dict, List
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Import the main travel assistant
from main import TravelAssistant

# Page configuration
st.set_page_config(
    page_title="Kavak Travel Assistant",
    page_icon="✈️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .main-header {
        text-align: center;
        padding: 2rem 0;
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        color: white;
        border-radius: 10px;
        margin-bottom: 2rem;
    }
    
    .chat-message {
        padding: 1rem;
        border-radius: 10px;
        margin: 1rem 0;
        border-left: 4px solid #667eea;
    }
    
    .user-message {
        background-color: #f0f2f6;
        border-left-color: #667eea;
    }
    
    .assistant-message {
        background-color: #e8f4fd;
        border-left-color: #1f77b4;
    }
    
    .flight-card {
        background: white;
        padding: 1rem;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        margin: 0.5rem 0;
        border-left: 4px solid #28a745;
    }
    
    .metric-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 1rem;
        border-radius: 8px;
        text-align: center;
    }
    
    .sidebar-section {
        background: #f8f9fa;
        padding: 1rem;
        border-radius: 8px;
        margin: 1rem 0;
    }
</style>
""", unsafe_allow_html=True)

def initialize_session_state():
    """Initialize session state variables."""
    if 'messages' not in st.session_state:
        st.session_state.messages = []
    
    if 'assistant' not in st.session_state:
        st.session_state.assistant = None
    
    if 'api_key_set' not in st.session_state:
        st.session_state.api_key_set = False

def setup_assistant(api_key: str):
    """Setup the travel assistant with API key."""
    try:
        if st.session_state.assistant is None:
            with st.spinner("Initializing Travel Assistant..."):
                st.session_state.assistant = TravelAssistant(api_key)
                st.session_state.api_key_set = True
        return True
    except Exception as e:
        st.error(f"Failed to initialize assistant: {str(e)}")
        return False

def display_message(message: Dict[str, str]):
    """Display a chat message with proper styling."""
    if message["role"] == "user":
        st.markdown(f"""
        <div class="chat-message user-message">
            <strong>🧑‍💼 You:</strong><br>
            {message["content"]}
        </div>
        """, unsafe_allow_html=True)
    else:
        st.markdown(f"""
        <div class="chat-message assistant-message">
            <strong>🤖 Travel Assistant:</strong><br>
            {message["content"]}
        </div>
        """, unsafe_allow_html=True)

def display_flight_results(response: str):
    """Parse and display flight results in a structured format."""
    if "✈️" in response and "Route:" in response:
        flights = response.split("✈️")[1:]  # Split by flight emoji
        
        st.subheader("🛫 Flight Search Results")
        
        for i, flight in enumerate(flights):
            if flight.strip():
                lines = flight.strip().split("\n")
                if len(lines) >= 5:
                    airline = lines[0].strip()
                    route = lines[1].replace("Route:", "").strip()
                    dates = lines[2].replace("Dates:", "").strip()
                    price = lines[3].replace("Price:", "").strip()
                    layovers = lines[4].replace("Layovers:", "").strip()
                    refundable = lines[5].replace("Refundable:", "").strip() if len(lines) > 5 else "N/A"
                    
                    with st.container():
                        col1, col2, col3 = st.columns([2, 1, 1])
                        
                        with col1:
                            st.markdown(f"**{airline}**")
                            st.write(f"📍 {route}")
                            st.write(f"📅 {dates}")
                        
                        with col2:
                            st.metric("Price", price)
                            st.write(f"🔄 {layovers}")
                        
                        with col3:
                            refund_color = "🟢" if "Yes" in refundable else "🔴"
                            st.write(f"{refund_color} {refundable}")
                        
                        st.divider()
    else:
        st.write(response)

def sidebar_content():
    """Display sidebar content with app information and controls."""
    st.sidebar.markdown("""
    <div class="sidebar-section">
        <h3>🌍 Kavak Travel Assistant</h3>
        <p>Your intelligent travel planning companion</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Initialize assistant with environment API key
    api_key = os.getenv('OPENAI_API_KEY', '')
    if api_key:
        if setup_assistant(api_key):
            st.sidebar.success("✅ Assistant Ready!")
        else:
            st.sidebar.error("❌ Setup Failed")
    else:
        st.sidebar.warning("⚠️ API Key Required in .env file")
    
    # Quick actions
    st.sidebar.markdown("### 🚀 Quick Actions")
    
    if st.sidebar.button("🔄 Clear Chat History"):
        st.session_state.messages = []
        st.rerun()
    

    
    # Statistics
    if st.session_state.assistant:
        st.sidebar.markdown("### 📊 Statistics")
        try:
            stats = st.session_state.assistant.flight_engine.get_flight_statistics()
            if stats:
                st.sidebar.metric("Total Flights", stats.get('total_flights', 0))
                st.sidebar.metric("Airlines", len(stats.get('airlines', [])))
                st.sidebar.metric("Destinations", len(stats.get('destinations', [])))
        except Exception:
            pass
    
    # About section
    st.sidebar.markdown("""
    <div class="sidebar-section">
        <h4>ℹ️ About</h4>
        <p>This assistant helps you:</p>
        <ul>
            <li>🔍 Search flights</li>
            <li>📋 Get visa information</li>
            <li>📜 Check travel policies</li>
            <li>💡 Plan your journey</li>
        </ul>
    </div>
    """, unsafe_allow_html=True)

def main():
    """Main Streamlit application."""
    initialize_session_state()
    
    # Header
    st.markdown("""
    <div class="main-header">
        <h1>✈️ Kavak Travel Assistant</h1>
        <p>Your intelligent companion for international travel planning</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Sidebar
    sidebar_content()
    
    # Main chat interface
    if not st.session_state.api_key_set:
        st.warning("🔑 Please enter your OpenAI API key in the sidebar to get started.")
        
        # Show demo information
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.markdown("""
            <div class="metric-card">
                <h3>🔍 Flight Search</h3>
                <p>Find flights with natural language queries</p>
            </div>
            """, unsafe_allow_html=True)
        
        with col2:
            st.markdown("""
            <div class="metric-card">
                <h3>📋 Visa Info</h3>
                <p>Get visa requirements and travel policies</p>
            </div>
            """, unsafe_allow_html=True)
        
        with col3:
            st.markdown("""
            <div class="metric-card">
                <h3>🤖 AI Powered</h3>
                <p>Intelligent responses with LangChain</p>
            </div>
            """, unsafe_allow_html=True)
        
        return
    
    # Display chat messages
    for message in st.session_state.messages:
        display_message(message)
    
    # Chat input
    if prompt := st.chat_input("Ask me about flights, visas, or travel policies..."):
        # Add user message
        st.session_state.messages.append({"role": "user", "content": prompt})
        display_message({"role": "user", "content": prompt})
        
        # Get assistant response
        with st.spinner("🤔 Thinking..."):
            try:
                response = st.session_state.assistant.chat_sync(prompt)
                
                # Add assistant message
                st.session_state.messages.append({"role": "assistant", "content": response})
                
                # Display response with special formatting for flights
                if "✈️" in response and "Route:" in response:
                    display_flight_results(response)
                else:
                    display_message({"role": "assistant", "content": response})
                
            except Exception as e:
                error_msg = f"I apologize, but I encountered an error: {str(e)}. Please try again."
                st.session_state.messages.append({"role": "assistant", "content": error_msg})
                display_message({"role": "assistant", "content": error_msg})
    
    # Footer
    st.markdown("""
    ---
    <div style="text-align: center; color: #666; padding: 1rem;">
        <p><small><strong>NOTE:</strong> Always verify travel information with official sources before making decisions.</small></p>
    </div>
    """, unsafe_allow_html=True)

if __name__ == "__main__":
    main()