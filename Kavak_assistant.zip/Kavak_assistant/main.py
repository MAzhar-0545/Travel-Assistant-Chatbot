#!/usr/bin/env python3
"""
Kavak Travel Assistant Chatbot
A conversational AI assistant for international travel planning.
"""

import os
import json
import asyncio
from typing import Dict, List, Optional, Any
from datetime import datetime
from dotenv import load_dotenv

from langchain.agents import AgentExecutor, create_openai_tools_agent
from langchain.tools import Tool
from langchain_openai import ChatOpenAI
from langchain_community.vectorstores import FAISS
from langchain_openai import OpenAIEmbeddings
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.schema import Document
from langchain.prompts import ChatPromptTemplate
from langchain_core.messages import HumanMessage, SystemMessage
from langchain.memory import ConversationBufferWindowMemory
from langchain_core.prompts import MessagesPlaceholder

from prompts.system_prompts import TRAVEL_ASSISTANT_PROMPT, FLIGHT_SEARCH_PROMPT, RAG_PROMPT
from utils.flight_search import FlightSearchEngine
from utils.rag_engine import RAGEngine
from utils.query_parser import QueryParser


class TravelAssistant:
    """Main travel assistant chatbot class."""
    
    def __init__(self, openai_api_key: str):
        self.openai_api_key = openai_api_key
        self.llm = ChatOpenAI(
            api_key=openai_api_key,
            model="gpt-3.5-turbo",
            temperature=0.7
        )
        
        # Initialize conversation memory
        self.memory = ConversationBufferWindowMemory(
            k=10,  # Keep last 10 exchanges
            memory_key="chat_history",
            return_messages=True
        )
        
        # Initialize components
        self.flight_engine = FlightSearchEngine()
        self.rag_engine = RAGEngine(openai_api_key)
        self.query_parser = QueryParser(self.llm)
        
        # Load data
        self._load_flight_data()
        self._setup_rag_knowledge_base()
        
        # Setup agent
        self._setup_agent()
    
    def _load_flight_data(self):
        """Load mock flight data."""
        try:
            with open('data/flights.json', 'r') as f:
                flights_data = json.load(f)
            self.flight_engine.load_flights(flights_data)
            print(f"Loaded {len(flights_data)} flight records")
        except FileNotFoundError:
            print("Warning: flights.json not found. Using empty flight database.")
            self.flight_engine.load_flights([])
    
    def _setup_rag_knowledge_base(self):
        """Setup RAG knowledge base from visa rules."""
        try:
            with open('data/visa_rules.md', 'r') as f:
                content = f.read()
            self.rag_engine.setup_knowledge_base(content)
            print("RAG knowledge base initialized")
        except FileNotFoundError:
            print("Warning: visa_rules.md not found. RAG functionality limited.")
    
    def _setup_agent(self):
        """Setup LangChain agent with tools."""
        tools = [
            Tool(
                name="search_flights",
                description="Search for flights based on user criteria. Input should be a natural language query describing the flight search (e.g., 'flights from Dubai to Tokyo departing August 15th').",
                func=self._search_flights_tool
            ),
            Tool(
                name="get_visa_info",
                description="Get visa and travel policy information. Input should be a question about visas, refunds, or travel policies.",
                func=self._get_visa_info_tool
            ),
            Tool(
                name="parse_travel_query",
                description="Parse and extract structured information from natural language travel queries.",
                func=self._parse_query_tool
            )
        ]
        
        # Add current date context to the system prompt
        current_date = datetime.now().strftime("%Y-%m-%d")
        enhanced_prompt = f"{TRAVEL_ASSISTANT_PROMPT}\n\n**CURRENT DATE**: {current_date}\n**IMPORTANT**: Use this current date for all date-related calculations and references."
        
        prompt = ChatPromptTemplate.from_messages([
            ("system", enhanced_prompt),
            MessagesPlaceholder(variable_name="chat_history"),
            ("human", "{input}"),
            ("placeholder", "{agent_scratchpad}")
        ])
        
        agent = create_openai_tools_agent(self.llm, tools, prompt)
        self.agent_executor = AgentExecutor(
            agent=agent,
            tools=tools,
            memory=self.memory,
            verbose=True,
            handle_parsing_errors=True
        )
    
    def _search_flights_tool(self, query: str) -> str:
        """Enhanced tool function for flight search with parameter validation."""
        try:
            # Parse the query if it's not already structured
            if isinstance(query, str) and not query.startswith('{'):
                parsed_query = self.query_parser.parse_flight_query(query)
            else:
                parsed_query = json.loads(query) if isinstance(query, str) else query
            
            # Validate required parameters before searching
            missing_params = []
            
            if not parsed_query.get('origin'):
                missing_params.append('origin city (departure location)')
            
            if not parsed_query.get('destination'):
                missing_params.append('destination city')
            
            if not parsed_query.get('departure_date'):
                missing_params.append('departure date')
            
            # If critical parameters are missing, ask for clarification
            if missing_params:
                missing_str = ', '.join(missing_params)
                return f"I need more information to search for flights. Please specify: {missing_str}.\n\nFor example: 'Find flights from Dubai to Tokyo departing August 15th'"
            
            # Validate query parameters
            validation_issues = self.query_parser.validate_query(parsed_query)
            if validation_issues:
                return f"Please clarify the following: {'; '.join(validation_issues)}"
            
            # Search for flights
            results = self.flight_engine.search_flights(parsed_query)
            
            if not results:
                # Provide helpful suggestions when no results found
                suggestions = self.flight_engine.suggest_alternatives(parsed_query)
                suggestion_text = "\n".join([f"• {s}" for s in suggestions]) if suggestions else ""
                
                return f"No flights found matching your criteria.\n\nSuggestions:\n{suggestion_text}\n\nPlease try adjusting your search parameters."
            
            # Format results for display with enhanced information
            formatted_results = []
            for i, flight in enumerate(results[:5], 1):  # Limit to top 5 results
                layover_info = ', '.join(flight.get('layovers', [])) or 'Direct'
                duration = f" ({flight.get('duration_hours', 'N/A')}h)" if flight.get('duration_hours') else ""
                
                formatted_results.append(
                    f"{i}. ✈️ {flight['airline']} ({flight.get('alliance', 'Independent')})\n"
                    f"   Route: {flight['from']} → {flight['to']}{duration}\n"
                    f"   Dates: {flight['departure_date']} - {flight.get('return_date', 'One-way')}\n"
                    f"   Price: ${flight['price_usd']} ({flight.get('class', 'economy').title()})\n"
                    f"   Layovers: {layover_info}\n"
                    f"   Refundable: {'Yes' if flight.get('refundable') else 'No'}\n"
                )
            
            # Add search summary
            search_summary = f"Found {len(results)} flights matching your criteria:\n\n"
            return search_summary + "\n".join(formatted_results)
            
        except Exception as e:
            return f"Error searching flights: {str(e)}"
    
    def _get_visa_info_tool(self, question: str) -> str:
        """Tool function for visa and policy information."""
        try:
            answer = self.rag_engine.query(question)
            return answer
        except Exception as e:
            return f"Error retrieving information: {str(e)}"
    
    def _parse_query_tool(self, query: str) -> str:
        """Tool function for parsing travel queries."""
        try:
            parsed = self.query_parser.parse_flight_query(query)
            return json.dumps(parsed, indent=2)
        except Exception as e:
            return f"Error parsing query: {str(e)}"
    
    async def chat(self, user_input: str) -> str:
        """Main chat interface with memory."""
        try:
            response = await self.agent_executor.ainvoke({
                "input": user_input,
                "chat_history": self.memory.chat_memory.messages
            })
            return response["output"]
        except Exception as e:
            return f"I apologize, but I encountered an error: {str(e)}. Please try rephrasing your question."

    def chat_sync(self, user_input: str) -> str:
        """Synchronous chat interface with memory."""
        try:
            response = self.agent_executor.invoke({
                "input": user_input,
                "chat_history": self.memory.chat_memory.messages
            })
            return response["output"]
        except Exception as e:
            return f"I apologize, but I encountered an error: {str(e)}. Please try rephrasing your question."


def main():
    """Main function for CLI interaction."""
    # Load environment variables from .env file
    load_dotenv()
    
    # Get OpenAI API key
    api_key = os.getenv('OPENAI_API_KEY')
    if not api_key:
        print("Please set your OPENAI_API_KEY environment variable.")
        return
    
    # Initialize assistant
    assistant = TravelAssistant(api_key)
    
    print("🌍 Welcome to Kavak Travel Assistant!")
    print("I can help you find flights, answer visa questions, and provide travel information.")
    print("Type 'quit' to exit.\n")
    
    while True:
        try:
            user_input = input("You: ").strip()
            
            if user_input.lower() in ['quit', 'exit', 'bye']:
                print("Thank you for using Kavak Travel Assistant! Safe travels! 🛫")
                break
            
            if not user_input:
                continue
            
            print("\nAssistant: ", end="")
            response = assistant.chat_sync(user_input)
            print(response)
            print("\n" + "-"*50 + "\n")
            
        except KeyboardInterrupt:
            print("\n\nGoodbye! 👋")
            break
        except Exception as e:
            print(f"\nError: {e}\n")


if __name__ == "__main__":
    main()